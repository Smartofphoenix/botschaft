import {Film} from "./films/film.model";

export interface ApiResponse {
  results: Film[];
}
