export interface FilmDetails {
  opening_crawl: string,
  characters: Character[]
}

export interface Character {
  name: string
}
