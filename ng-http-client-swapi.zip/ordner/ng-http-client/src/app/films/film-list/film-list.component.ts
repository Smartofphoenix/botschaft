import {Component, OnInit} from '@angular/core';
import {FilmService} from "../film.service";
import {Film} from "../film.model";
import {FilmItemComponent} from "../film-item/film-item.component";

@Component({
  selector: 'app-film-list',
  standalone: true,
  imports: [
    FilmItemComponent
  ],
  templateUrl: './film-list.component.html',
  styleUrl: './film-list.component.css'
})
export class FilmListComponent implements OnInit {
  films: Film[] = [];

  constructor(private filmService: FilmService) {
  }

  ngOnInit(): void {
    this.filmService.getAll().subscribe((films) => this.films = films);
  }


}
