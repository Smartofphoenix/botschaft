import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {Film} from "./film.model";
import {ApiResponse} from "../api-response.model";
import {Character, FilmDetails} from "./film-details.model";

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  constructor(private httpClient: HttpClient) {
  }

  private readonly baseUrl = 'https://swapi.dev/api/films';

  getAll(): Observable<Film[]> {
    return this.httpClient
      .get<ApiResponse>(this.baseUrl)
      .pipe(map(res => res.results));
  }

  get(index: number): Observable<FilmDetails> {
    return this.httpClient
      .get<FilmDto>(`${this.baseUrl}/${index + 1}`)
      .pipe(map(res => {
        const characters: Character[] = [];
        for (let character of res.characters) {
          this.httpClient
            .get<Character>(character)
            .subscribe(c => characters.push(c));
        }
        return {
          opening_crawl: res.opening_crawl,
          characters: characters
        };
      }));
  }
}

interface FilmDto {
  opening_crawl: string,
  characters: string
}
