import {Component, Input} from '@angular/core';
import {Film} from "../film.model";
import {FilmService} from "../film.service";
import {FilmDetails} from "../film-details.model";
import {JsonPipe} from "@angular/common";

@Component({
  selector: 'app-film-item',
  standalone: true,
  imports: [
    JsonPipe
  ],
  templateUrl: './film-item.component.html',
  styleUrl: './film-item.component.css'
})
export class FilmItemComponent {
  @Input({required: true}) film!: Film;
  details?: FilmDetails;
  @Input({required: true}) index!: number;

  constructor(private filmService: FilmService) {
  }


  onFilmClicked() {
    if (!this.details) {
      this.filmService.get(this.index).subscribe(details => this.details = details);
    } else
      this.details = undefined;
  }
}
