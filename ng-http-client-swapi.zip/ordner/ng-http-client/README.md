## http wars

[SWAPI](https://swapi.dev/) ist ein frei verfügbares API, welches Informationen zu Star Wars Filmen bereitstellt. Die Antworten des APIs können dauern. 

1. Zeige eine Liste aller Filme mit Episodennummer, Titel und Veröffentlichungsdatum
  ![](./images/films.png)
2. Wird auf einen Film geklickt so wird zusätzlich der Opening-Crawl angezeigt und die Namen aller Charaktere dieses Films
  ![](./images/details.png)
3. Ein erneuter Klick auf einen Film klappt diesen wieder ein
